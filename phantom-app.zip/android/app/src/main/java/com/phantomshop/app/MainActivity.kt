package com.phantomshop.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * پوستهٔ ساده‌ی اندروید برای سایت فانتوم شاپ: همان سایت داخل یک WebView تمام‌صفحه باز می‌شود.
 * - فقط دامنهٔ خودِ سایت داخل برنامه باز می‌شود؛ لینک‌های بیرونی (تلگرام، آپارات و ...) با برنامهٔ مربوط باز می‌شوند.
 * - انتخاب فایل (رسید پرداخت، ویدیو، تصویر) پشتیبانی می‌شود.
 * - دکمهٔ بازگشت ابتدا در تاریخچهٔ سایت برمی‌گردد.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var offlineView: TextView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val siteHost: String = Uri.parse(BuildConfig.SITE_URL).host ?: ""

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uris = android.webkit.WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 6)
            max = 100
            visibility = View.GONE
        }
        offlineView = TextView(this).apply {
            text = "اتصال به اینترنت برقرار نیست.\nدوباره امتحان کن."
            setTextColor(0xFFCCCCCC.toInt())
            textSize = 16f
            gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE; web.reload() }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(offlineView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress)
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false   // ویدیوی تبلیغ (بی‌صدا) خودکار پخش شود
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == siteHost) return false   // داخل برنامه
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }              // بیرون برنامه
                catch (e: ActivityNotFoundException) { Toast.makeText(this@MainActivity, "برنامه‌ای برای باز کردن این لینک نیست.", Toast.LENGTH_SHORT).show() }
                return true
            }
            override fun onPageFinished(view: WebView, url: String) { progress.visibility = View.GONE }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) offlineView.visibility = View.VISIBLE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { chooser.launch(params.createIntent()); true }
                catch (e: ActivityNotFoundException) { fileCallback = null; false }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(BuildConfig.SITE_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); web.saveState(outState) }
    override fun onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
