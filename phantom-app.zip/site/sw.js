/* Service worker فانتوم شاپ: فقط «پوستهٔ» برنامه را برای باز شدن سریع و حالت آفلاین نگه می‌دارد.
   هیچ‌وقت درخواست‌های API، سفارش، پرداخت یا منابع بیرونی (نرخ دلار، صرافی‌ها و ...) را کش نمی‌کند،
   پس قیمت و وضعیت سفارش همیشه تازه از شبکه می‌آید. */
const CACHE = 'phantom-shell-v1';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;        // فقط GET همین دامنه
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/uploads/')) return; // API و فایل‌های آپلودی هرگز کش نشوند
  if (req.headers.has('range')) return;                                            // ویدیو (Range) را به مرورگر بسپار
  // صفحه‌ها: اول شبکه (نسخهٔ تازه)، اگر آفلاین بود از کش
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put('index.html', copy)); return res; })
        .catch(() => caches.match('index.html'))
    );
    return;
  }
  // آیکون و فایل‌های ثابت: از کش، همزمان در پس‌زمینه تازه می‌شود
  e.respondWith(
    caches.match(req).then((hit) => {
      const net = fetch(req).then((res) => { if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return res; }).catch(() => hit);
      return hit || net;
    })
  );
});
